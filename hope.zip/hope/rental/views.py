from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy, reverse
from django.contrib import messages
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.utils import timezone

from .models import Car, Booking
from .forms import BookingForm, CarSearchForm
from .utils import notify_admin_about_booking

class HomeView(TemplateView):
    template_name = 'rental/home.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['featured_cars'] = Car.objects.filter(available=True)[:6]
        return context

class CarListView(ListView):
    model = Car
    template_name = 'rental/car_list.html'
    context_object_name = 'cars'
    paginate_by = 9

    def get_queryset(self):
        queryset = Car.objects.all()
        form = CarSearchForm(self.request.GET)

        if form.is_valid():
            # Apply filters if form is valid
            if form.cleaned_data.get('search'):
                search_query = form.cleaned_data['search']
                queryset = queryset.filter(
                    Q(name__icontains=search_query) |
                    Q(brand__icontains=search_query) |
                    Q(description__icontains=search_query)
                )

            if form.cleaned_data.get('car_type'):
                queryset = queryset.filter(type=form.cleaned_data['car_type'])

            if form.cleaned_data.get('min_price'):
                queryset = queryset.filter(price_per_day__gte=form.cleaned_data['min_price'])

            if form.cleaned_data.get('max_price'):
                queryset = queryset.filter(price_per_day__lte=form.cleaned_data['max_price'])

            if form.cleaned_data.get('available_only'):
                queryset = queryset.filter(available=True)

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = CarSearchForm(self.request.GET)
        return context

class CarDetailView(DetailView):
    model = Car
    template_name = 'rental/car_detail.html'
    context_object_name = 'car'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.is_authenticated:
            context['booking_form'] = BookingForm(car=self.object, user=self.request.user)
        return context

@login_required
def create_booking(request, car_id):
    car = get_object_or_404(Car, id=car_id)

    if request.method == 'POST':
        form = BookingForm(request.POST, car=car, user=request.user)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.car = car
            booking.user = request.user
            booking.status = 'awaiting_approval'  # Set status to awaiting approval
            booking.save()

            # Send email notification to admin
            notify_admin_about_booking(booking)

            messages.success(request, 'Booking created successfully! It is awaiting admin approval. You will be notified when it is approved.')
            return redirect('booking_detail', pk=booking.pk)
    else:
        form = BookingForm(car=car, user=request.user)

    return render(request, 'rental/booking_form.html', {
        'form': form,
        'car': car,
    })

class BookingDetailView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    model = Booking
    template_name = 'rental/booking_detail.html'
    context_object_name = 'booking'

    def test_func(self):
        booking = self.get_object()
        return booking.user == self.request.user or self.request.user.is_staff

class BookingListView(LoginRequiredMixin, ListView):
    model = Booking
    template_name = 'rental/booking_list.html'
    context_object_name = 'bookings'
    paginate_by = 10

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['active_bookings'] = self.get_queryset().filter(
            status='confirmed',
            end_date__gte=timezone.now().date()
        )
        context['past_bookings'] = self.get_queryset().filter(
            Q(status='completed') | Q(end_date__lt=timezone.now().date())
        )
        context['cancelled_bookings'] = self.get_queryset().filter(status='cancelled')
        return context

@login_required
def cancel_booking(request, pk):
    booking = get_object_or_404(Booking, pk=pk)

    # Check if user owns this booking
    if booking.user != request.user and not request.user.is_staff:
        messages.error(request, 'You do not have permission to cancel this booking.')
        return redirect('booking_list')

    # Check if booking can be cancelled
    if not booking.can_be_cancelled():
        messages.error(request, 'This booking cannot be cancelled.')
        return redirect('booking_detail', pk=booking.pk)

    if request.method == 'POST':
        booking.status = 'cancelled'
        booking.save()
        messages.success(request, 'Booking cancelled successfully.')
        return redirect('booking_list')

    return render(request, 'rental/booking_cancel.html', {'booking': booking})

class DashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'rental/dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user

        # Get user's active bookings
        context['active_bookings'] = Booking.objects.filter(
            user=user,
            status='confirmed',
            end_date__gte=timezone.now().date()
        )[:5]

        # Get user's recent bookings
        context['recent_bookings'] = Booking.objects.filter(user=user).order_by('-created_at')[:5]

        return context
