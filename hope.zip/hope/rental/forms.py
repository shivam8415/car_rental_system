from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Booking, Car

class CustomSignupForm(UserCreationForm):
    """Custom signup form with better error handling for duplicate usernames"""

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise ValidationError(f"The username '{username}' is already taken. Please choose a different username.")
        return username

    def signup(self, request, user):
        """Required method for django-allauth"""
        # You can perform additional actions here if needed
        return user

class DateInput(forms.DateInput):
    input_type = 'date'

class CarSearchForm(forms.Form):
    """Form for searching cars based on various criteria"""
    search = forms.CharField(required=False, label='Search',
                            widget=forms.TextInput(attrs={'placeholder': 'Search by name or brand'}))
    car_type = forms.ChoiceField(required=False, label='Car Type',
                                choices=[('', 'All Types')] + list(Car.CAR_TYPES))
    min_price = forms.DecimalField(required=False, label='Min Price', min_value=0)
    max_price = forms.DecimalField(required=False, label='Max Price', min_value=0)
    available_only = forms.BooleanField(required=False, label='Available Only', initial=True)

    def clean(self):
        cleaned_data = super().clean()
        min_price = cleaned_data.get('min_price')
        max_price = cleaned_data.get('max_price')

        if min_price and max_price and min_price > max_price:
            raise ValidationError('Minimum price cannot be greater than maximum price')

        return cleaned_data

class BookingForm(forms.ModelForm):
    """Form for creating and updating bookings"""
    class Meta:
        model = Booking
        fields = ['start_date', 'end_date']
        widgets = {
            'start_date': DateInput(),
            'end_date': DateInput(),
        }

    def __init__(self, *args, **kwargs):
        self.car = kwargs.pop('car', None)
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

        # Set minimum date to today
        today = timezone.now().date()
        self.fields['start_date'].widget.attrs['min'] = today.isoformat()
        self.fields['end_date'].widget.attrs['min'] = today.isoformat()

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')

        if start_date and end_date:
            # Check if end date is after start date
            if end_date < start_date:
                raise ValidationError('End date must be after start date')

            # Check if start date is not in the past
            today = timezone.now().date()
            if start_date < today:
                raise ValidationError('Start date cannot be in the past')

            # Check if the car is available for the selected dates
            if self.car:
                # Get all confirmed bookings for this car that overlap with the requested period
                overlapping_bookings = Booking.objects.filter(
                    car=self.car,
                    status='confirmed',
                ).exclude(
                    # Exclude the current booking if we're editing
                    pk=self.instance.pk if self.instance.pk else None
                ).filter(
                    # Check for overlapping dates
                    (models.Q(start_date__lte=start_date) & models.Q(end_date__gte=start_date)) |  # Booking starts during another booking
                    (models.Q(start_date__lte=end_date) & models.Q(end_date__gte=end_date)) |      # Booking ends during another booking
                    (models.Q(start_date__gte=start_date) & models.Q(end_date__lte=end_date))      # Another booking is entirely within this booking
                )

                if overlapping_bookings.exists():
                    raise ValidationError('The car is not available for the selected dates')

        return cleaned_data

    def save(self, commit=True):
        booking = super().save(commit=False)
        if self.car:
            booking.car = self.car
        if self.user:
            booking.user = self.user

        # Calculate total price
        duration = (booking.end_date - booking.start_date).days
        booking.total_price = booking.car.price_per_day * duration

        if commit:
            booking.save()
        return booking
