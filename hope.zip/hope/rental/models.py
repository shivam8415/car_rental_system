from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.urls import reverse

class Car(models.Model):
    CAR_TYPES = (
        ('sedan', 'Sedan'),
        ('suv', 'SUV'),
        ('hatchback', 'Hatchback'),
        ('convertible', 'Convertible'),
        ('luxury', 'Luxury'),
        ('sports', 'Sports'),
    )

    name = models.CharField(max_length=100)
    type = models.CharField(max_length=20, choices=CAR_TYPES)
    brand = models.CharField(max_length=50)
    price_per_day = models.DecimalField(max_digits=8, decimal_places=2)
    image = models.ImageField(upload_to='cars/', blank=True, null=True)
    description = models.TextField()
    available = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.brand} {self.name}"

    def get_absolute_url(self):
        return reverse('car_detail', kwargs={'pk': self.pk})

    def get_price_in_rupees(self):
        """Convert price from dollars to rupees (1 USD = 80 INR)"""
        return self.price_per_day * 80

class Booking(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('awaiting_approval', 'Awaiting Approval'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
        ('completed', 'Completed'),
        ('rejected', 'Rejected'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='bookings')
    start_date = models.DateField()
    end_date = models.DateField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} - {self.car} ({self.start_date} to {self.end_date})"

    def get_absolute_url(self):
        return reverse('booking_detail', kwargs={'pk': self.pk})

    def get_duration(self):
        """Calculate the duration of the booking in days"""
        delta = self.end_date - self.start_date
        return delta.days

    def save(self, *args, **kwargs):
        # Calculate total price if not already set
        if not self.total_price:
            duration = self.get_duration()
            # Price is stored in dollars but displayed in rupees
            self.total_price = self.car.price_per_day * duration
        super().save(*args, **kwargs)

    def get_total_price_in_rupees(self):
        """Convert total price from dollars to rupees (1 USD = 80 INR)"""
        return self.total_price * 80

    def is_active(self):
        """Check if the booking is currently active"""
        today = timezone.now().date()
        return self.start_date <= today <= self.end_date and self.status == 'confirmed'

    def can_be_cancelled(self):
        """Check if the booking can be cancelled"""
        today = timezone.now().date()
        return today < self.start_date and self.status != 'cancelled'
