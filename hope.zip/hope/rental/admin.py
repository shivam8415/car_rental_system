from django.contrib import admin
from django.utils.html import format_html
from django.contrib import messages
from .models import Car, Booking
from .utils import notify_user_about_booking_status

@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ('brand', 'name', 'type', 'price_per_day', 'available')
    list_filter = ('type', 'brand', 'available')
    search_fields = ('name', 'brand', 'description')
    list_editable = ('available', 'price_per_day')
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        ('Car Information', {
            'fields': ('name', 'brand', 'type', 'price_per_day', 'description')
        }),
        ('Availability', {
            'fields': ('available',)
        }),
        ('Media', {
            'fields': ('image',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'car', 'start_date', 'end_date', 'total_price_display', 'status_with_badge', 'created_at')
    list_filter = ('status', 'start_date', 'end_date')
    search_fields = ('user__username', 'car__name', 'car__brand')
    readonly_fields = ('created_at', 'updated_at', 'total_price')
    actions = ['approve_bookings', 'reject_bookings']
    fieldsets = (
        ('Booking Information', {
            'fields': ('user', 'car', 'start_date', 'end_date', 'total_price')
        }),
        ('Status', {
            'fields': ('status',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(user=request.user)

    def status_with_badge(self, obj):
        status_colors = {
            'pending': 'bg-gray-500',
            'awaiting_approval': 'bg-yellow-500',
            'confirmed': 'bg-green-500',
            'cancelled': 'bg-red-500',
            'completed': 'bg-blue-500',
            'rejected': 'bg-red-700',
        }
        color = status_colors.get(obj.status, 'bg-gray-500')
        return format_html(
            '<span style="padding: 5px 10px; border-radius: 10px; color: white; background-color: {}">{}</span>',
            color, obj.get_status_display()
        )
    status_with_badge.short_description = 'Status'

    def total_price_display(self, obj):
        return format_html('₹{}', int(obj.get_total_price_in_rupees()))
    total_price_display.short_description = 'Total Price (₹)'

    def approve_bookings(self, request, queryset):
        updated = queryset.filter(status='awaiting_approval').update(status='confirmed')

        # Send notification emails to users
        for booking in queryset.filter(status='confirmed'):
            notify_user_about_booking_status(booking)

        if updated == 0:
            self.message_user(request, 'No bookings were approved. Only bookings with status "Awaiting Approval" can be approved.', messages.WARNING)
        else:
            self.message_user(request, f'{updated} booking(s) were successfully approved and users have been notified.', messages.SUCCESS)
    approve_bookings.short_description = 'Approve selected bookings'

    def reject_bookings(self, request, queryset):
        updated = queryset.filter(status='awaiting_approval').update(status='rejected')

        # Send notification emails to users
        for booking in queryset.filter(status='rejected'):
            notify_user_about_booking_status(booking)

        if updated == 0:
            self.message_user(request, 'No bookings were rejected. Only bookings with status "Awaiting Approval" can be rejected.', messages.WARNING)
        else:
            self.message_user(request, f'{updated} booking(s) were successfully rejected and users have been notified.', messages.SUCCESS)
    reject_bookings.short_description = 'Reject selected bookings'
