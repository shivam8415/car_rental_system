from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.models import User
from django.urls import reverse

def notify_admin_about_booking(booking):
    """
    Send an email notification to all admin users about a new booking.
    In development, this will print to the console if EMAIL_BACKEND is set to console backend.
    """
    # Get all admin users
    admin_users = User.objects.filter(is_staff=True)
    admin_emails = [user.email for user in admin_users if user.email]
    
    if not admin_emails:
        return  # No admin emails to notify
    
    # Create the booking approval URL
    booking_admin_url = f"/admin/rental/booking/{booking.id}/change/"
    
    # Create the email subject and message
    subject = f"New Car Booking #{booking.id} Awaiting Approval"
    message = f"""
    A new booking has been made and is awaiting your approval:
    
    Booking ID: {booking.id}
    User: {booking.user.username} ({booking.user.email})
    Car: {booking.car.brand} {booking.car.name}
    Dates: {booking.start_date} to {booking.end_date}
    Total Price: ₹{booking.get_total_price_in_rupees()}
    
    Please log in to the admin panel to approve or reject this booking:
    {settings.SITE_URL if hasattr(settings, 'SITE_URL') else 'http://127.0.0.1:8000'}{booking_admin_url}
    
    Thank you,
    Car Rental System
    """
    
    # Send the email
    send_mail(
        subject=subject,
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@carrental.com',
        recipient_list=admin_emails,
        fail_silently=True,
    )
    
    return True

def notify_user_about_booking_status(booking):
    """
    Send an email notification to the user about their booking status change.
    """
    if not booking.user.email:
        return  # No user email to notify
    
    status_map = {
        'confirmed': 'approved',
        'rejected': 'rejected',
        'cancelled': 'cancelled',
    }
    
    status_text = status_map.get(booking.status, booking.status)
    
    # Create the email subject and message
    subject = f"Your Car Booking #{booking.id} has been {status_text}"
    message = f"""
    Dear {booking.user.username},
    
    Your booking has been {status_text}:
    
    Booking ID: {booking.id}
    Car: {booking.car.brand} {booking.car.name}
    Dates: {booking.start_date} to {booking.end_date}
    Total Price: ₹{booking.get_total_price_in_rupees()}
    Status: {booking.get_status_display()}
    
    {'We look forward to serving you!' if booking.status == 'confirmed' else ''}
    {'We apologize for any inconvenience caused.' if booking.status == 'rejected' else ''}
    
    Thank you,
    Car Rental System
    """
    
    # Send the email
    send_mail(
        subject=subject,
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@carrental.com',
        recipient_list=[booking.user.email],
        fail_silently=True,
    )
    
    return True
